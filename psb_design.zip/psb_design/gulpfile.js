'use strict';

var
    chalk           = require('chalk'),
    gulp            = require('gulp'),
    browserSync     = require('browser-sync').create(),
    clean           = require('gulp-clean'),
    plumber         = require('gulp-plumber'),
    gulpif          = require('gulp-if'),
    concat          = require('gulp-concat'),
    stylus          = require('gulp-stylus'),
    autoprefix      = require('gulp-autoprefixer'),
    minifyCss       = require('gulp-minify-css'),
    sequence        = require('run-sequence'),
    replace         = require('gulp-replace'),
    uglify          = require('gulp-uglify'),

    flags           = require('minimist')(process.argv.slice(2)),
    isProduction    = flags.production || flags.prod || false,
    watching        = flags.watch || false
;

// BUILD ------------------------------------------------------------------------ //

var build = {
    css: {
        name: 'app.css',
        dest: 'public/build/css'
    },
    js: {
        name: 'app.js',
        dest: 'public/build/js'
    }
};

gulp.task('build', function(callback) {
    console.log(chalk.green('Building ' + (isProduction ? 'production' : 'dev') + ' version...'));

    if (flags.watch) {
        sequence(
            'clean',
            [
                'js',
                'css'
            ],
            'watch',
            function() {
                callback();
                console.log(chalk.green('Big brother is watching you...'))
            }
        )
    } else {
        sequence(
            'clean',
            [
                'js',
                'css'
            ],
            function() {
                callback();
                console.log(chalk.green('✔ All done!'))
            }
        )
    }
});

// CLEAN ------------------------------------------------------------------------ //

gulp.task('clean', function() {
    return gulp.src([
        build.css.dest
    ])
        .pipe(clean());
});

// CSS ------------------------------------------------------------------------ //
gulp.task('css', function() {
    var css = gulp.src([
        // reset default styles
        'src/resources/css/reset.css',
        'src/resources/css/global.css',
        'src/resources/css/fonts.css',

        'src/resources/css/*/*.css',
        'src/resources/css/*/*/*.css',
        'src/resources/css/*/*/*/*.css'
    ])
        .pipe(plumber())
        .pipe(stylus({
            'include css': true,
            import: [__dirname + '/resources/assets/css/$vars.styl'],
            compress: (isProduction ? true : false)
        }))
        .pipe(concat(build.css.name))
        .pipe(autoprefix('last 2 version', 'ie 8', 'ie 9'))
        .pipe(gulpif(isProduction, minifyCss({keepSpecialComments: 0})))
        .pipe(gulp.dest(build.css.dest))
        .pipe(gulpif(watching, browserSync.stream()));

    return css;
});

// JS ------------------------------------------------------------------------ //
gulp.task('js', function() {
    var js = gulp.src([
        'src/resources/js/modules/svgLoader.js'
    ])
        .pipe(plumber())
        .pipe(concat(build.js.name))

        .pipe(gulpif(isProduction, replace(/(\/\/)?(console\.)?log\((.*?)\);?/g, '')))
        .pipe(gulpif(isProduction, uglify()))
        .pipe(gulp.dest(build.js.dest));


    return js;
});

// WATCH ------------------------------------------------------------------------ //
gulp.task('watch', function() {
    // Watch .css files
    gulp.watch('src/resources/css/*.css', ['css']);
    gulp.watch('src/resources/css/*/*.css', ['css']);
    gulp.watch('src/resources/css/*/*/*.css', ['css']);
    gulp.watch('src/resources/css/*/*/*/*.css', ['css']);
});

// DEFAULT ---------------------------------------------------------------------- //
gulp.task('default', function() {
    gulp.start('build');
});